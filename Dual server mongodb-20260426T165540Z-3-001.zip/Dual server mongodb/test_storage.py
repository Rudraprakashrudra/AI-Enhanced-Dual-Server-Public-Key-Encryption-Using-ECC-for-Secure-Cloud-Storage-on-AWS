#!/usr/bin/env python3
"""
Test script to verify MongoDB GridFS storage functionality
"""
import io
from utils.storage import upload_to_mongodb, get_file_from_mongodb, delete_file_from_mongodb

def test_upload_download():
    print("Testing MongoDB GridFS storage...")

    # Create a test file
    test_content = b"Hello, this is a test file for MongoDB GridFS!"
    test_filename = "test_file.txt"
    test_file = io.BytesIO(test_content)

    print(f"\n1. Uploading test file '{test_filename}'...")
    file_id = upload_to_mongodb(test_file, test_filename, content_type="text/plain")
    print(f"   ✓ File uploaded with ID: {file_id}")

    print(f"\n2. Downloading file with ID: {file_id}...")
    grid_out = get_file_from_mongodb(file_id)
    downloaded_content = grid_out.read()
    print(f"   ✓ File downloaded, filename: {grid_out.filename}")
    print(f"   ✓ Content type: {grid_out.content_type}")

    print(f"\n3. Verifying content integrity...")
    if downloaded_content == test_content:
        print("   ✓ Content matches! Upload and download successful.")
    else:
        print("   ✗ Content mismatch! Something went wrong.")
        return False

    print(f"\n4. Cleaning up - deleting test file...")
    delete_file_from_mongodb(file_id)
    print("   ✓ File deleted successfully")

    print("\n✅ All tests passed! MongoDB GridFS storage is working correctly.")
    return True

if __name__ == "__main__":
    try:
        test_upload_download()
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
