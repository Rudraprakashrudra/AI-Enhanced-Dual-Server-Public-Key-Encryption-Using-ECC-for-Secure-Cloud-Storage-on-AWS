from Crypto.PublicKey import ECC

# Generate key pair
key = ECC.generate(curve='P-256')
priv_key = key.export_key(format='PEM')
pub_key = key.public_key().export_key(format='PEM')

# Save to PEM files
with open("private_key.pem", "w") as f:
    f.write(priv_key)

with open("public_key.pem", "w") as f:
    f.write(pub_key)

print("✅ Keys saved to private_key.pem and public_key.pem")
