from flask import Flask, render_template, request, redirect, session, url_for
import requests

app = Flask(__name__)
app.secret_key = "supersecure"  # change in prod

AS_URL = "http://localhost:8000"
TS_URL = "http://localhost:9000"

@app.route("/")
def home():
    return redirect("/login")

# ---------------- Auth ----------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        data = {
            "email": request.form["email"],
            "password": request.form["password"]
        }
        res = requests.post(f"{AS_URL}/auth/register", data=data).json()
        return render_template("register.html", msg=res)
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        data = {
            "email": request.form["email"],
            "password": request.form["password"]
        }
        res = requests.post(f"{AS_URL}/auth/login", data=data).json()
        if "msg" in res:
            session["email"] = data["email"]
            return redirect("/dashboard")
        return render_template("login.html", error=res)
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")

# ---------------- Dashboard ----------------
@app.route("/dashboard")
def dashboard():
    if "email" not in session:
        return redirect("/login")

    as_data = requests.post(f"{AS_URL}/dashboard", data={"email": session["email"]}).json()
    ts_data = requests.get(f"{TS_URL}/dashboard").json()
    return render_template("dashboard.html", as_data=as_data, ts_data=ts_data)

# ---------------- Upload ----------------
@app.route("/upload", methods=["GET", "POST"])
def upload():
    if "email" not in session:
        return redirect("/login")
    with open("keys/public_key.pem", "r") as f:
        pubkey = f.read()

    if request.method == "POST":
        file = request.files["file"]
        keyword = request.form["keyword"]
        filename = request.form["filename"]

        res = requests.post(f"{AS_URL}/upload", data={
            "filename": filename,
            "keyword": keyword,
            "user_pubkey": pubkey,
            "email": session["email"]
        }, files={"file": file})

        print("🔥 Upload response code:", res.status_code)
        print("📄 Raw response text:", res.text)


        try:
            status = res.json()
        except requests.exceptions.JSONDecodeError:
            status = {"error": "❌ Failed to upload. Server returned non-JSON response.", "raw": res.text}

        return render_template("upload.html", status=status)

    return render_template("upload.html")

# ---------------- Search ----------------
@app.route("/search", methods=["GET", "POST"])
def search():
    if "email" not in session:
        return redirect("/login")
    with open("keys/private_key.pem", "r") as f:
        privkey = f.read()
    with open("keys/public_key.pem", "r") as f:
        pubkey = f.read()

    results, suggestions = None, None
    if request.method == "POST":
        response = requests.post(f"{AS_URL}/search", data={
            "keyword": request.form["keyword"],
            "user_secret": privkey,
            "user_pubkey": pubkey,
            "email": session["email"]
        })

        print("Raw response:", response.text)  

        try:
            res = response.json()
        except Exception as e:
            print("JSON decode error:", e)
            res = {}

        results = res.get("results")
        print("Results returned:", results)
        suggestions = res.get("ai_suggestions")

    return render_template("search.html", results=results, suggestions=suggestions)

if __name__ == "__main__":
    app.run(debug=True)