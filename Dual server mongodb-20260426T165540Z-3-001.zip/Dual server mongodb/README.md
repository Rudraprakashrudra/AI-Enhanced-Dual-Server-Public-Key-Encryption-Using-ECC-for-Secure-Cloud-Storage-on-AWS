# Dual Server - MongoDB Only Version

This is a modified version of the Dual Server project that uses **MongoDB GridFS** for file storage instead of AWS S3.

## Key Differences from Original

### File Storage
- **Original**: Uses AWS S3 for file storage with presigned URLs
- **MongoDB Version**: Uses MongoDB GridFS for file storage with local download endpoints

### Changes Made

1. **New Storage Module** (`utils/storage.py`):
   - `upload_to_mongodb()`: Uploads files to GridFS
   - `get_file_from_mongodb()`: Retrieves files from GridFS
   - `delete_file_from_mongodb()`: Deletes files from GridFS

2. **Updated Upload Routes**:
   - `auth_server/routes/upload.py`: Now uses `upload_to_mongodb()`
   - `backend/routes/upload.py`: Now uses `upload_to_mongodb()`
   - Files are stored in MongoDB with `file_id` instead of `s3_url`

3. **New Download Route** (`auth_server/routes/download.py`):
   - `/download/{file_id}`: Downloads files from GridFS
   - Returns files with proper content type and filename

4. **Updated Dashboard**:
   - `frontend/templates/dashboard.html`: Now uses local download URLs
   - Download links: `http://localhost:8001/download/{file_id}`

5. **Removed Files**:
   - `utils/s3.py`: Deleted (no longer needed)

## Requirements

- MongoDB installed and running on `localhost:27017`
- Python dependencies:
  - `pymongo`
  - `fastapi`
  - `gridfs` (included with pymongo)

## Installation

1. Ensure MongoDB is running:
   ```bash
   sudo systemctl start mongodb
   ```

2. Install Python dependencies (if not already installed):
   ```bash
   pip install pymongo fastapi uvicorn pycryptodome
   ```

3. No AWS credentials needed!

## Running the Servers

Start all servers as usual:

```bash
# Auth Server (port 8001)
python -m uvicorn auth_server.main:app --port 8001 --reload

# Trapdoor Server (port 8002)
python -m uvicorn trapdoor_server.main:app --port 8002 --reload

# Backend Server (port 8000)
python -m uvicorn backend.main:app --port 8000 --reload

# Frontend (port 5000)
python frontend/app.py
```

## Advantages of MongoDB-Only Version

1. **No Cloud Dependencies**: Runs completely locally
2. **No AWS Costs**: Free MongoDB storage
3. **Simpler Setup**: No AWS credentials or S3 bucket configuration needed
4. **Easier Development**: All data stored locally for testing
5. **Better Privacy**: Files never leave your infrastructure

## Database Structure

Files are stored in MongoDB with the following metadata:
```json
{
  "filename": "example.pdf",
  "file_id": "507f1f77bcf86cd799439011",  // GridFS file_id
  "encrypted_keyword": "base64_encrypted_keyword",
  "uploader_email": "user@example.com",
  "mime": "application/pdf",
  "user_pubkey": "-----BEGIN PUBLIC KEY-----..."
}
```

The actual file content is stored in GridFS collections:
- `fs.files`: File metadata
- `fs.chunks`: File data chunks

## Notes

- Files are stored with unique IDs using `uuid.uuid4().hex`
- Download links are generated dynamically and don't expire
- GridFS efficiently handles large files by chunking them
