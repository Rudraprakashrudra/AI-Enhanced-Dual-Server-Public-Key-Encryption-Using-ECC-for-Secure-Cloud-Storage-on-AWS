from fastapi import APIRouter, Form
from utils.db import get_user_files

router = APIRouter()

@router.post("/dashboard")
def dashboard(email: str = Form(...)):
    files = get_user_files(email)
    return {"file_count": len(files), "files": files}
