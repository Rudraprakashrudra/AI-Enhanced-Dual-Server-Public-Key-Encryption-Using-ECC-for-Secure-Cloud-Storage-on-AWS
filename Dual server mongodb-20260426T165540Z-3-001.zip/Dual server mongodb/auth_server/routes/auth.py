from fastapi import APIRouter, Form
from utils.db import create_user, find_user_by_email
from hashlib import sha256

router = APIRouter()

@router.post("/register")
def register(email: str = Form(...), password: str = Form(...)):
    if find_user_by_email(email):
        return {"error": "User exists"}
    hashed = sha256(password.encode()).hexdigest()
    create_user({"email": email, "password": hashed})
    return {"msg": "Registered"}

@router.post("/login")
def login(email: str = Form(...), password: str = Form(...)):
    user = find_user_by_email(email)
    if not user:
        return {"error": "No such user"}
    if sha256(password.encode()).hexdigest() != user["password"]:
        return {"error": "Wrong password"}
    return {"msg": "Login successful"}
