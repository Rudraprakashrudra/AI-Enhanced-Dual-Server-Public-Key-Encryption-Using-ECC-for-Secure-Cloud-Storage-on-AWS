from fastapi import APIRouter, Form
from utils.crypto import trapdoor_gen
import requests
from utils.ai import expand_keywords
import os
from utils.crypto import load_private_key

router = APIRouter()

@router.post("/search")
def search_from_auth_server(
    keyword: str = Form(...),
    email: str = Form(...),
    user_pubkey: str = Form(...)
):
    private_key = load_private_key()
    trapdoor = trapdoor_gen(keyword, private_key)

    ts_response = requests.post(
        "http://localhost:9000/match",
        data={
            "trapdoor": trapdoor,
            "keyword": keyword,
            "user_pubkey": user_pubkey
        }
    )

    try:
        results = ts_response.json()
    except Exception as e:
        results = []

    ai_suggestions = expand_keywords(keyword)
    print(ai_suggestions)

    return {
        "results": results,
        "trapdoor": trapdoor,
        "ai_suggestions": ai_suggestions
    }