from fastapi import APIRouter, UploadFile, Form
from utils.crypto import encrypt_keyword
from utils.storage import upload_to_mongodb
from utils.db import store_file_metadata
from Crypto.Hash import SHA256
import base64
router = APIRouter()

@router.post("/upload")
async def upload_file(
    file: UploadFile,
    filename: str = Form(...),  # new manual filename input
    keyword: str = Form(...),
    user_pubkey: str = Form(...),
    email: str = Form(...)
):

    enc_keyword = base64.b64encode(SHA256.new(keyword.encode()).digest()).decode()
    print("Saved encrypted keyword:", enc_keyword)

    # Upload to MongoDB GridFS instead of S3
    file_id = upload_to_mongodb(file.file, filename=filename, content_type=file.content_type)

    metadata = {
        "filename": filename,
        "file_id": file_id,  # Store file_id instead of s3_url
        "encrypted_keyword": enc_keyword,
        "uploader_email": email,
        "mime": file.content_type,
        "user_pubkey": user_pubkey
    }
    store_file_metadata(metadata)

    return {"status": "uploaded", "file_id": file_id}
