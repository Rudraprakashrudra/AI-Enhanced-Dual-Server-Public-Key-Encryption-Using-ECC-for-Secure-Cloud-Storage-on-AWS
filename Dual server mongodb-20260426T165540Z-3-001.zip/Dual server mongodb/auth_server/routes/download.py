from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from utils.storage import get_file_from_mongodb
from bson.errors import InvalidId
import io

router = APIRouter()

@router.get("/download/{file_id}")
async def download_file(file_id: str):
    """
    Download file from MongoDB GridFS by file_id
    """
    try:
        # Get file from GridFS
        grid_out = get_file_from_mongodb(file_id)

        # Read file data
        file_data = grid_out.read()

        # Create streaming response
        return StreamingResponse(
            io.BytesIO(file_data),
            media_type=grid_out.content_type or "application/octet-stream",
            headers={
                "Content-Disposition": f"attachment; filename={grid_out.filename}"
            }
        )
    except InvalidId:
        raise HTTPException(status_code=400, detail="Invalid file ID")
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"File not found: {str(e)}")
