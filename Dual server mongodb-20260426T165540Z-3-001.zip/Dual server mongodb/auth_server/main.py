from fastapi import FastAPI
from auth_server.routes.search import router as search_router
from auth_server.routes.auth import router as auth_router
from auth_server.routes.dashboard import router as dashboard_router
from auth_server.routes.upload import router as upload_router
from auth_server.routes.download import router as download_router

app = FastAPI()
app.include_router(search_router)
app.include_router(auth_router, prefix="/auth")
app.include_router(dashboard_router)
app.include_router(upload_router)
app.include_router(download_router)

@app.get("/")
def ping():
    return {"msg": "Auth Server Ready"}