from fastapi import APIRouter, Form
from utils.crypto import trapdoor_gen
from utils.db import find_files_by_trapdoor
from utils.ai import expand_keywords

search_router = APIRouter()

@search_router.post("/")
def search_files(keyword: str = Form(...), user_secret: str = Form(...)):
    trapdoor = trapdoor_gen(keyword, user_secret)
    matches = find_files_by_trapdoor(trapdoor)

    # Generate AI-based keyword suggestions
    suggestions = expand_keywords(keyword)

    return {
        "results": matches,
        "ai_suggestions": suggestions
    }