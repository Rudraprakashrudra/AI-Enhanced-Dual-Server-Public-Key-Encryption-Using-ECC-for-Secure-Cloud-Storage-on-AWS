from fastapi import APIRouter, UploadFile, Form
from utils.crypto import encrypt_keyword
from utils.db import store_file_metadata
from utils.storage import upload_to_mongodb
upload_router = APIRouter()



@upload_router.post("/")
async def upload_file(file: UploadFile, keyword: str = Form(...), user_pubkey: str = Form(...)):
    enc_keyword = encrypt_keyword(keyword, user_pubkey)
    file_id = upload_to_mongodb(file.file, filename=file.filename, content_type=file.content_type)

    metadata = {
        "filename": file.filename,
        "file_id": file_id,  # Store file_id instead of s3_url
        "encrypted_keyword": enc_keyword,
        "uploader_pubkey": user_pubkey
    }
    store_file_metadata(metadata)
    return {"status": "uploaded", "file_id": file_id}

