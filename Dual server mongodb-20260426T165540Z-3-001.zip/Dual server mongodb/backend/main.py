from fastapi import FastAPI
from routes.upload import upload_router
from routes.search import search_router

app = FastAPI()

app.include_router(upload_router, prefix="/upload")
app.include_router(search_router, prefix="/search")

@app.get("/")
def root():
    return {"msg": "🔐 Secure Search Backend Active"}
