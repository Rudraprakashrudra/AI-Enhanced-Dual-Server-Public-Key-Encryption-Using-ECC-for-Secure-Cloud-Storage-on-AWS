from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017")
db = client.secure_search
collection = db.files

def store_file_metadata(data):
    collection.insert_one(data)

def find_files_by_trapdoor(enc_kw):
    print("Querying for:", enc_kw)
    result = list(files.find({"encrypted_keyword": enc_kw}))
    print("MongoDB matched:", result)
    return result

files = db.files
users = db.users
logs = db.logs

def create_user(data): users.insert_one(data)
def find_user_by_email(email): return users.find_one({"email": email})

def log_event(event): logs.insert_one(event)
def get_logs(): return list(logs.find())
def get_user_files(email):
    docs = list(files.find({"uploader_email": email}))
    for doc in docs:
        doc["_id"] = str(doc["_id"])  # or use doc.pop("_id", None)
    return docs
