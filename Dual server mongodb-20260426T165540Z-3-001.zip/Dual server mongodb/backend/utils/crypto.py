from Crypto.PublicKey import ECC
import hashlib
import os
# ECC Key Generation
def generate_keys():
    key = ECC.generate(curve='P-256')
    private_key = key.export_key(format='PEM')
    public_key = key.public_key().export_key(format='PEM')
    return private_key, public_key

# Simulated Keyword Encryption
def encrypt_keyword(keyword: str, public_key: str):
    return hashlib.sha256((keyword + public_key).encode()).hexdigest()
def load_private_key():
    with open(os.path.abspath("frontend/keys/private_key.pem"), "r") as f:
        return f.read()
# Trapdoor Generation
from Crypto.Signature import DSS
from Crypto.Hash import SHA256
from Crypto.PublicKey import ECC
import base64
def trapdoor_gen(keyword: str, privkey_pem: str):
    key = ECC.import_key(privkey_pem)
    h = SHA256.new(keyword.encode())
    signer = DSS.new(key, 'fips-186-3')
    signature = signer.sign(h)
    return base64.b64encode(signature).decode()