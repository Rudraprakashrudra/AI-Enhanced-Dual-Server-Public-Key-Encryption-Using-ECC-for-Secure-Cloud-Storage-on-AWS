import spacy

nlp = spacy.load("en_core_web_sm")

def expand_keywords(text):
    doc = nlp(text)
    keywords = set()

    # Extract noun chunks
    for chunk in doc.noun_chunks:
        keywords.add(chunk.text.lower())

    # Extract named entities (optional)
    for ent in doc.ents:
        keywords.add(ent.text.lower())

    return list(keywords)

