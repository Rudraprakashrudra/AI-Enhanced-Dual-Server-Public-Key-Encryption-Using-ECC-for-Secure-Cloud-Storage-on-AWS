from pymongo import MongoClient
import gridfs
import uuid

# MongoDB connection
client = MongoClient("mongodb://localhost:27017")
db = client.secure_search
fs = gridfs.GridFS(db)

def upload_to_mongodb(file_obj, filename, content_type=None):
    """
    Upload file to MongoDB GridFS
    Returns file_id that can be used to retrieve the file
    """
    # Generate unique filename
    unique_filename = f"{uuid.uuid4().hex}_{filename}"

    # Store file in GridFS
    file_id = fs.put(
        file_obj,
        filename=unique_filename,
        content_type=content_type
    )

    # Return the file_id as string
    return str(file_id)


def get_file_from_mongodb(file_id):
    """
    Retrieve file from MongoDB GridFS by file_id
    Returns GridOut object containing file data
    """
    from bson.objectid import ObjectId
    return fs.get(ObjectId(file_id))


def delete_file_from_mongodb(file_id):
    """
    Delete file from MongoDB GridFS
    """
    from bson.objectid import ObjectId
    fs.delete(ObjectId(file_id))
