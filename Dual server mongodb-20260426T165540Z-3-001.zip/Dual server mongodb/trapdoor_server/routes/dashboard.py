from fastapi import APIRouter
from utils.db import get_logs

router = APIRouter()

@router.get("/dashboard")
def ts_dashboard():
    logs = get_logs()
    return {"trapdoor_requests": len(logs), "log_data": logs}
