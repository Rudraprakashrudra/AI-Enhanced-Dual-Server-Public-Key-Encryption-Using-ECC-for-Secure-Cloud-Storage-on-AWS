from fastapi import APIRouter, Form
from utils.db import find_files_by_trapdoor
from Crypto.PublicKey import ECC
from Crypto.Signature import DSS
from Crypto.Hash import SHA256
import base64

router = APIRouter()

@router.post("/match")
def trapdoor_match(trapdoor: str = Form(...), keyword: str = Form(...), user_pubkey: str = Form(...)):
    try:
        # Recreate signature & hash
        signature = base64.b64decode(trapdoor)
        key = ECC.import_key(user_pubkey)
        h = SHA256.new(keyword.encode())
        verifier = DSS.new(key, 'fips-186-3')
        print("Decoded signature:", signature)
        print("Verifying with pubkey:\n", user_pubkey)

        verifier.verify(h, signature)

        # If signature is valid, match encrypted keyword
        encrypted = base64.b64encode(SHA256.new(keyword.encode()).digest()).decode()
        print("Looking for encrypted keyword:", encrypted)
        files = find_files_by_trapdoor(encrypted)
        print(files)
        clean_files = []
        for f in files:
            f["_id"] = str(f["_id"])  # remove ObjectId issue
            f["filename"] = f.get("filename", "Untitled")  # ensure key exists
            clean_files.append(f)

        return clean_files

    except Exception as e:
        return {"error": "Invalid trapdoor signature", "details": str(e)}
