from fastapi import FastAPI
from trapdoor_server.routes.match import router as match_router
from trapdoor_server.routes.dashboard import router as dashboard_router

app = FastAPI()
app.include_router(match_router)
app.include_router(dashboard_router)

@app.get("/")
def ping():
    return {"msg": "Trapdoor Server Ready"}
